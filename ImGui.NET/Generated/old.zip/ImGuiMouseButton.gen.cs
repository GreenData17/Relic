namespace ImGuiNET
{
    public enum ImGuiMouseButton
    {
        Left = 0,
        Right = 1,
        Middle = 2,
        COUNT = 5,
    }
}
