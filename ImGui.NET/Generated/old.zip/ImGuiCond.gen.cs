namespace ImGuiNET
{
    public enum ImGuiCond
    {
        None = 0,
        Always = 1,
        Once = 2,
        FirstUseEver = 4,
        Appearing = 8,
    }
}
