namespace ImGuiNET
{
    [System.Flags]
    public enum ImGuiKeyModFlags
    {
        None = 0,
        Ctrl = 1,
        Shift = 2,
        Alt = 4,
        Super = 8,
    }
}
